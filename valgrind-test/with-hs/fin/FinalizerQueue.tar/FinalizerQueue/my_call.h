typedef void (*my_thunk)(void);
void my_call_2(my_thunk,my_thunk);
