void buzz(int array_length, int array[]);
